#include <bits/stdc++.h>
#define PI 3.14159
using namespace std;
int main()
{
    int t;
    scanf("%d",&t);
    for(int i=0;i<t;i++)
    {
        int r;
        scanf("%d",&r);
        double AB,area;
        AB = r*1.4142;
        AB = AB/2;
        area = AB * AB * PI;
        printf("%.2lf\n",area);
    }
}