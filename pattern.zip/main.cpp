#include <bits/stdc++.h>
using namespace std;
int main()
{
    int t;
    scanf("%d",&t);
    for(int i=0;i<t;i++)
    {
        int n;
        scanf("%d",&n);
        for(int j=1;j<=n;j++)
        {
            for(int k=j;k<n;k++)
            {
                printf(" ");
            }
            for(int l=j;l>=1;l--)
            {
                printf("%d",l);
                
            }
            if(j>1)
            {
                for(int m=2;m<=j;m++)
                {
                    printf("%d",m);
                }
            }
            printf("\n");
        }
        for(int j=n-1;j>=1;j--)
        {
            for(int k=j;k<n;k++)
            {
                printf(" ");
            }
            for(int l=j;l>=1;l--)
            {
                printf("%d",l);
                
            }
            if(j>1)
            {
                for(int m=2;m<=j;m++)
                {
                    printf("%d",m);
                }
            }
            printf("\n");
        }
    }
}