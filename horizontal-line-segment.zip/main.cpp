#include <bits/stdc++.h>
using namespace std;
int main()
{
    int t;
    scanf("%d",&t);
   
    for(int i=0;i<t;i++)
    {
         long long x1,x2,x3,x4,y1,y2,y3,y4;
         scanf("%lld %lld %lld %lld",&x1,&y1,&x2,&y2);
         scanf("%lld %lld %lld %lld",&x3,&y3,&x4,&y4);
         if(y1==y3)
         {
             continue;
             
         }
         else if(x4<x1 || x2<x3 )
        {
            printf("NO\n");
        }
         else {printf("YES\n");}
    }
}

