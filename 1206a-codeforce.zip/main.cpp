#include <bits/stdc++.h>
using namespace std;
int main()
{
    srand(time(NULL));
    int n,m,s,p,q,c;
    cin>>n;
    int A[n];
    for(int i=0;i<n;i++)
    {
        cin>>A[i];
    }
    cin>>m;
    int B[m];
    for(int i=0;i<m;i++)
    {
        cin>>B[i];
    }
    p=A[rand()%n];
    q=B[rand()%m];
    
    s=p+q;
    for(int i=0;i<n;i++)
    {
        if(s!=A[i])
        {
      for(int j=0;j<m;j++)
        {
            if(s!=B[j])
            {
                
                c=1;   
            }
            else
            c=0;
        
        }
        }
        else 
        c=0;
    }
    if(c==1)
     cout<<p<<' '<<q<<endl;
}