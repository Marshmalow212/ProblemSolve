#include <bits/stdc++.h>
using namespace std;
int main()
{
    int l=7;
    int p[l];
    for(int i=0;i<l;i++)
    {
        cin>>p[i];
    }
    long int c[l];
    for(int i=0;i<l;i++)
    {
        cin>>c[i];
    }
    sort(c,c+l,greater<int>());
    //reverse(c,c+l);
    int q;
    cin>>q;
         
    while(q--)
    {
        int j=0;
        long long int n=0;
        cin>>n;
        n--;
        if(n>7)
        {
            n==n
        }
        j = p[n]-1;
        cout<<c[j]<<endl;
        
    }
    
}
