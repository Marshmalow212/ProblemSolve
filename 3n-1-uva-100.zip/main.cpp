#include <bits/stdc++.h>
using namespace std;
int main()
{
    long int m,n,i,t,k,j,c;
    while(cin>>m>>n)
    {
        cout<<m<<' '<<n<<' ';
        c=0;
        if(n>m)
        {
            k=m;
            m=n;
            n=k;
        }
        for(j=m;j>=n;j--)
        {
         for(i=1,t=j;t!=1;i++)
            {
            if(t%2==0)
            {
                t=t/2;
            }
            else
            {
                t=(3*t)+1;
            }
            }
            if(i>c)
             {c=i;}
        }
        cout<<c<<endl;
    }
}

