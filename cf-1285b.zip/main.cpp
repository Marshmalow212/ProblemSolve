#include <bits/stdc++.h>
using namespace std;

int main()
{
    int t;
    cin>>t;
    while(t--)
    {
        int n;
        cin>>n;
        vector<int>c;
        for(int i=0;i<n;i++)
        {
            int k;
            cin>>k;
            c.push_back(k);
        }
        for(auto x:c)cout<<c[x]<<endl;
    }
}