#include <bits/stdc++.h>
using namespace std;
int main()
{
    int t;
    cin>>t;
    int cnt = 1;
    while(t--)
    {
        long long n, a, v,x,y;
        cin>>n;
        a = ceil(sqrt(n));
        v = (a*a)-a +1;
        if(a%2)
        {
            if(v < n)
            {
                x= a - (n-v);
                y= a;
            }
            else if(v==n)
            {
                x=y=a;
            }
            else 
            {
                x=a;
                y= a - (v-n);
            }
        }
        else
        {
            if(v > n)
            {
                x= a - (v-n);
                y= a;
            }
            else if(v==n)
            {
                x=y=a;
            }
            else 
            {
                x=a;
                y= a - (n - v);
            }
        }
        cout<<"Case "<<cnt++<<": ";
        cout<<x<<" "<<y<<endl;
    }
}