#include <bits/stdc++.h>
using namespace std;
int main()
{
    int m,n,r;
    scanf("%d %d %d",&m,&n,&r);
    int matrix[m][n];
    for(int i=0;i<m;i++)
    {
        for(int j=0;j<n;j++)
        {
            scanf("%d",&matrix[i][j]);
        }
    }
    m--;n--;
    
    int t1,t2;
    int c=0,p=0,i,j;
    if(m<n && m%2==0){c=m/2;}
    else if(n<m && n%2==0){c=n/2;}
    else if(m==n && m%2==0){c=n/2;}
    while(r<=1)
    {
        
        int s=0;
        while(p<c)
        {
            
            t1 = matrix[m][n];
    for(j=n,i=m;i>s;i--){
         t2=t1; 
        t1=matrix[i-1][j];
        matrix[i-1][j]=t2;
        
        
    }
    for(i=0,j=n;j>s;j--){
        t2=t1; 
        t1=matrix[i][j-1];
        matrix[i][j-1]=t2;
    }
    for(j=i=s;i<m-1;i++){
        t2=t1; 
        t1=matrix[i+1][j];
        matrix[i+1][j]=t2;
    }
    for( i=m,j=s;j<n-1;j++){
        t2=t1; 
        t1=matrix[i][j+1];
        matrix[i][j+1]=t2;
    }
    m--;n--;s++;
    p++;
    
            
    }
        r--;
    }
    for(i=0;i<=m;i++)
    {
        for(j=0;j<=n;j++)
        {
            printf("%d ",matrix[i][j]);
        }
        printf("\n");
    }
    
}
    