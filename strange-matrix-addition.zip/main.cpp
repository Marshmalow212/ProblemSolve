#include <bits/stdc++.h>
using namespace std;
int main()
{
    int t;
    cin>>t;
    for(int a=0;a<t;a++)
    {
    int r, cx, cy, n;
    cin>>r>>cx>>cy>>n;
    int x[r][cx],y[r][cy];
    for(int i=0;i<r;i++)
    {
        for(int j=0;j<cx;j++)
        {
            cin>>x[i][j];
        }
    }
    for(int i=0;i<r;i++)
    {
         for(int j=0;j<cy;j++)
        {
            cin>>y[i][j];
        }
    
    }
    //if(cx<cy)
    //{
        for(int i=0;i<r;i++)
    {
        for(int j=0;j<cx-n;j++)
        {
            cout<<x[i][j]<<' ';
        }
        for(int k=cx-n,l=0;k<cx;k++,l++)
        {
            cout<<(x[i][k]+y[i][l])<<' ';
        }
        for(int m=n;m<cy;m++)
        {
            cout<<y[i][m]<<' ';
        }
        cout<<endl;
    }
    //}
    /*else if(cy<cx)
    {
        for(int i=0;i<r;i++)
    {
        for(int j=0;j<n-1;j++)
        {
            cout<<y[i][j]<<' ';
        }
        for(int k=n-1,l=0;k<=n;k++,l++)
        {
            cout<<(y[i][k]+x[i][l])<<' ';
        }
        for(int m=n;m<cx;m++)
        {
            cout<<x[i][m]<<' ';
        }
        cout<<endl;
    }
    }*/
    
    
    }
    
}