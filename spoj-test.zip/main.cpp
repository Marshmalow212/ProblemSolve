#include<bits/stdc++.h>
using namespace std;
int main()
{
    vector<int>v;
    int x;
    while(cin>>x)
    {
        v.push_back(x);
    }
    for(int i=0;i<v.size();i++)
    {
        if(v[i]==42)break;
        else cout<<v[i]<<endl;
    }
    
}