#include <bits/stdc++.h>
using namespace std;
int main()
{
    int n;
    string s;
    cin>>n;
    cin>>s;
    int c=0;
    int x=1;
    x+=n;
    cout<<x<<endl;
}
